<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/students/all/', [StudentController::class, 'studentsShowAll']);
Route::get('/students/{id}/', [StudentController::class, 'studentsShowID']);
Route::get('/students/create/{name}/', [StudentController::class, 'studentCreateName']);
Route::post('/newpage' , [StudentController::class, 'NameToInput']);

Route::get('/', function () {
    return view('welcome', ['name' => 'Welcome']);
});
